from pydantic import BaseModel


class DiscordString(BaseModel):
    value: str

    